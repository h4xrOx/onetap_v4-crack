System.config({
    map: {
        imports: {
            "bind-imgui": "../build/bind-imgui.js",
            "imgui-js": "../build/imgui.js",
            "main": "./build/main.js",
        }
    },
});
